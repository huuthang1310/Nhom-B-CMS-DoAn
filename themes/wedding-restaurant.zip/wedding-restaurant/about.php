<?php /* Template Name: About */ ?>
<?php get_header(); ?>
<div id="wrap-body">
    <?php get_template_part( 'module/module-wp/module-wp-10', 'about' ); ?>
    <?php get_template_part( 'module/module-wp/module-wp-11', 'about' ); ?>
    <?php get_template_part( 'module/module-wp/module-wp-12', 'about' ); ?>
	<?php get_template_part( 'module/module-wp/module-wp-13', 'about' ); ?>
	<?php get_template_part( 'module/module-wp/module-wp-14', 'about' ); ?>
	<?php get_template_part( 'module/module-wp/module-wp-15', 'about' ); ?>
</div>
<?php get_footer(); ?>