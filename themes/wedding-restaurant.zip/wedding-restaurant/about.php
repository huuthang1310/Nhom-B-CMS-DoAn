<?php /* Template Name: About */ ?>
<?php get_header(); ?>
<div id="wrap-body">
    <?php get_template_part( 'module/module-wp/module-10', 'about' ); ?>
    <?php get_template_part( 'module/module-wp/module-11', 'about' ); ?>
    <?php get_template_part( 'module/module-wp/module-3', 'about' ); ?>
	<?php get_template_part( 'module/module-wp/module-8', 'about' ); ?>
</div>
<?php get_footer(); ?>