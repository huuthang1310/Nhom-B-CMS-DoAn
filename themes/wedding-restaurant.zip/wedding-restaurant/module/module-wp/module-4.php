<section>
    <div class="container">
        <div class="bg-offset bg-size-80"
            data-image-src="<?php echo get_template_directory_uri()?>/images/food-3327977_960_720.png"
            style="background-image: url(&quot;<?php echo get_template_directory_uri()?>/images/food-3327977_960_720.png&quot;);">
            <div class="row">
                <div class="col-md-8 col-lg-6 f-right">
                    <div class="bg-f p-40 p-xs-20 card box-shadow-sm border-1x">
                        <div class="card-body">
                            <div>
                                <div class="block-title m-b-50">
                                    <h4 class="card-subtitle">Sale up to 20%</h4>
                                    <h2 class="line-default f-30">week's special</h2>
                                </div>
                                <div class="menu-food">
                                    <h4 class="d-flex">
                                        <a href="http://templatecs.com/demo/template/deliki/html/home.html#">Tomato
                                            Bruscgetta</a>
                                        <span class="col"></span>
                                        <span>$9.00</span>
                                    </h4>
                                    <p>Tomatoes, Olive Oil, Cheese</p>
                                </div>
                                <div class="menu-food">
                                    <h4 class="d-flex">
                                        <a href="http://templatecs.com/demo/template/deliki/html/home.html#">Gnocchi con
                                            speck</a>
                                        <span class="col"></span>
                                        <span>$9.00</span>
                                    </h4>
                                    <p>Tomatoes, Olive Oil, Cheese</p>
                                </div>
                                <div class="menu-food">
                                    <h4 class="d-flex">
                                        <a href="http://templatecs.com/demo/template/deliki/html/home.html#">Crema di
                                            funghi</a>
                                        <span class="col"></span>
                                        <span>$9.00</span>
                                    </h4>
                                    <p>Tomatoes, Olive Oil, Cheese</p>
                                </div>
                                <div class="menu-food">
                                    <h4 class="d-flex">
                                        <a href="http://templatecs.com/demo/template/deliki/html/home.html#">Tomato
                                            salad</a>
                                        <span class="col"></span>
                                        <span>$9.00</span>
                                    </h4>
                                    <p>Tomatoes, Olive Oil, Cheese</p>
                                </div>
                                <div class="menu-food">
                                    <h4 class="d-flex">
                                        <a href="http://templatecs.com/demo/template/deliki/html/home.html#">Cheese
                                            burger</a>
                                        <span class="col"></span>
                                        <span>$9.00</span>
                                    </h4>
                                    <p>Tomatoes, Olive Oil, Cheese</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>