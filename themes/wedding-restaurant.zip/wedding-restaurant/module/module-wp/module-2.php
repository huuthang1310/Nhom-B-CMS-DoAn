<section class="banner p-0">
    <div class="card bg-offset card-5x"
        data-image-src="<?php echo get_template_directory_uri()?>/images/kawin-haraffsai-75421.jpg"
        style="background-image: url(&quot;<?php echo get_template_directory_uri() ?>/images/kawin-haraffsai-75421.jpg&quot;);">
        <div></div>
        <div class="card-img-overlay">
            <div class="container">
                <div class="max-w-700">
                    <h4 class="card-subtitle f-30 color-f f-sm-25 m-b-15">Save up to 25%</h4>
                    <h1 class="card-title f-sm-40 f-xs-35 f-weight-900">Delicious <strong
                            class="main-color">Food</strong> </h1>
                    <h6 class="card-text max-w-800 f-20 f-sm-13">Breadfast - Luch - Dinner - Dersert - Wine</h6>
                    <a href="http://templatecs.com/demo/template/deliki/html/home.html#"
                        class="btn btn-lg m-t-50">discovery menu</a>
                </div>
            </div>
        </div>
    </div>
</section>