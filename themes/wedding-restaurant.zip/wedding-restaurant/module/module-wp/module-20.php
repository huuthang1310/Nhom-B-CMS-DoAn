<div class="card card-5x">
	<img src="<?php echo get_template_directory_uri() ?>/images/pizza-2000614_960_720.jpg" alt="image">
	<div class="card-body">
		<h2 class="card-title">
			<a href="http://templatecs.com/demo/template/deliki/html/blog_list.html#">Mountain mike’s pizza opens new location in redwood city</a>
		</h2>
		<p class="card-date">September 12, 2017</p>
		<p>Lorem ipsum dolor sit amet consectetur adipisicing labore et dolore magna aliqua uat veniama icing elit sed do eiusmoLorem ipsum dolor sit amet gth hjhjh jk,,consectetur adipisicing labore et dolore magnadolor sit amet consectetur adipisicing labore et dolore magna aliqua uat veniama icing elit sed do eiusmo Lorem ipsum dolor sit amet gth hjhjh jk,,consectetur adipisicing labore et dolore magna</p>
		<a href="http://templatecs.com/demo/template/deliki/html/blog_list.html#" class="btn">read more</a>
	</div>
</div>
<div class="card card-5x">
	<img src="<?php echo get_template_directory_uri() ?>/images/stefan-johnson-124186.jpg" alt="image">
	<div class="card-body">
		<h2 class="card-title">
			<a href="http://templatecs.com/demo/template/deliki/html/blog_list.html#">Corner bakery is now offering fresh, wholesome seasonal specials</a>
		</h2>
		<p class="card-date">September 12, 2017</p>
		<p>Lorem ipsum dolor sit amet consectetur adipisicing labore et dolore magna aliqua uat veniama icing elit sed do eiusmoLorem ipsum dolor sit amet gth hjhjh jk,,consectetur adipisicing labore et dolore magnadolor sit amet consectetur adipisicing labore et dolore magna aliqua uat veniama icing elit sed do eiusmo Lorem ipsum dolor sit amet gth hjhjh jk,,consectetur adipisicing labore et dolore magna</p>
		<a href="http://templatecs.com/demo/template/deliki/html/blog_list.html#" class="btn">read more</a>
	</div>
</div>
<div class="card card-5x">
	<img src="<?php echo get_template_directory_uri() ?>/images/stefan-johnson-124186.jpg" alt="image">
	<div class="card-body">
		<h2 class="card-title">
			<a href="http://templatecs.com/demo/template/deliki/html/blog_list.html#">Capriotti’s sandwich shop ignites 2019 with momentous growth</a>
		</h2>
		<p class="card-date">September 12, 2017</p>
		<p>Lorem ipsum dolor sit amet consectetur adipisicing labore et dolore magna aliqua uat veniama icing elit sed do eiusmoLorem ipsum dolor sit amet gth hjhjh jk,,consectetur adipisicing labore et dolore magnadolor sit amet consectetur adipisicing labore et dolore magna aliqua uat veniama icing elit sed do eiusmo Lorem ipsum dolor sit amet gth hjhjh jk,,consectetur adipisicing labore et dolore magna</p>
		<a href="http://templatecs.com/demo/template/deliki/html/blog_list.html#" class="btn">read more</a>
	</div>
</div>