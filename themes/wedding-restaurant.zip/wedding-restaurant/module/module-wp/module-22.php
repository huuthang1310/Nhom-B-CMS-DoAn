<section class="page-title">
	<div class="card bg-offset bg-fixed h250" data-image-src="<?php echo get_template_directory_uri() ?>/images/kawin-haraffsai-75421.jpg" style="background-image: url(&quot;<?php echo get_template_directory_uri() ?>/images/kawin-haraffsai-75421.jpg&quot;);">
		<div class="card-img-overlay">
			<div class="container">
				<h1>blog list</h1>
			</div>
		</div>
	</div>
</section>