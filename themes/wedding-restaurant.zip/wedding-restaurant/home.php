<?php /* Template Name: Home */ ?>
<?php get_header(); ?>
<div id="wrap-body">
    <?php get_template_part( 'module/module-wp/module-2', 'home' ); ?>
    <?php get_template_part( 'module/module-wp/module-3', 'home' ); ?>
    <?php get_template_part( 'module/module-wp/module-4', 'home' ); ?>
    <?php get_template_part( 'module/module-wp/module-5', 'home' ); ?>
    <?php get_template_part( 'module/module-wp/module-6', 'home' ); ?>
    <?php get_template_part( 'module/module-wp/module-7', 'home' ); ?>
    <?php get_template_part( 'module/module-wp/module-8', 'home' ); ?> 
</div>
<?php get_footer(); ?>